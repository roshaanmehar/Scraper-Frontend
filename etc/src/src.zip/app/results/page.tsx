import ResultsPage from "@/components/ResultsPage"

export default function Results() {
  return <ResultsPage />
}
