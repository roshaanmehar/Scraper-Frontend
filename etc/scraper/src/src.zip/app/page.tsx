import ScraperControlPanel from "@/components/ScraperControlPanel"

export default function Home() {
  return (
    <main>
      <ScraperControlPanel />
    </main>
  )
}
