import fs from "fs"
import path from "path"
import { MongoClient } from "mongodb"
import { scrapePostcodes } from "./postcodes-scraper.js"
import { scrapeGoogleMaps } from "./google-maps-scraper.js"
import { scrapeEmails } from "./emails-scraper.js"

// Log function for tracking script execution
function log(message) {
  const timestamp = new Date().toISOString()
  const logMessage = `[${timestamp}] ${message}`
  console.log(logMessage)

  // Ensure logs directory exists
  const logDir = path.join(process.cwd(), "server", "logs")
  if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir, { recursive: true })
  }

  // Append to log file
  fs.appendFileSync(path.join(logDir, "scraper.log"), logMessage + "\n")
}

// MongoDB connection helper
async function connectToMongo() {
  const uri = process.env.MONGODB_URI || "mongodb://localhost:27017"
  const client = new MongoClient(uri)
  await client.connect()
  return client
}

// Check if database exists
export async function checkDatabaseExists(cityName) {
  const client = await connectToMongo()
  try {
    const adminDb = client.db("admin")
    const dbs = await adminDb.admin().listDatabases()

    // Check if database with city name exists (case insensitive)
    return dbs.databases.some((db) => db.name.toLowerCase() === cityName.toLowerCase())
  } finally {
    await client.close()
  }
}

// Run the entire scraping workflow
export async function runScrapeWorkflow(cityName, postcodeArea, keyword) {
  // Create a unique job ID
  const jobId = `scrape-${cityName}-${Date.now()}`
  log(`Starting scrape workflow ${jobId} for ${cityName} (${postcodeArea})`)

  try {
    // Check if database exists
    const dbExists = await checkDatabaseExists(cityName)
    log(`Database check for ${cityName}: ${dbExists ? "EXISTS" : "DOES NOT EXIST"}`)

    // Step 1: Run postcodes scraper if needed
    if (!dbExists) {
      log(`Database for ${cityName} does not exist. Running postcodes scraper...`)
      await scrapePostcodes(cityName, postcodeArea)
    } else {
      log(`Database for ${cityName} already exists. Skipping postcodes scraper.`)
    }

    // Step 2: Run Google Maps scraper
    log(`Starting Google Maps scraper for ${cityName} with keyword "${keyword}"...`)
    await scrapeGoogleMaps(cityName, keyword)

    // Step 3: Wait 90 seconds, then run the emails scraper
    const delaySeconds = process.env.SCRAPE_DELAY_SECONDS || 90
    log(`Waiting ${delaySeconds} seconds before starting email scraper...`)

    // Use setTimeout to delay the email scraper
    return new Promise((resolve) => {
      setTimeout(async () => {
        log(`Delay complete. Starting email scraper for ${cityName}...`)
        const emailResult = await scrapeEmails(cityName)

        log(`Scrape workflow ${jobId} completed successfully`)
        resolve({
          success: true,
          message: `Scrape workflow for ${cityName} completed successfully`,
          jobId,
          emailsFound: emailResult.emails,
        })
      }, delaySeconds * 1000)
    })
  } catch (error) {
    log(`Error in scrape workflow ${jobId}: ${error.message}`)
    return {
      success: false,
      message: `Scrape workflow for ${cityName} failed: ${error.message}`,
      jobId,
      error: error.message,
    }
  }
}

// Get status of current scraping jobs
export function getScraperStatus() {
  try {
    // Read the log file to determine current status
    const logFilePath = path.join(process.cwd(), "server", "logs", "scraper.log")

    if (!fs.existsSync(logFilePath)) {
      return {
        status: "idle",
        message: "No scraper has been run yet",
        lastRun: null,
      }
    }

    const logContent = fs.readFileSync(logFilePath, "utf8")
    const logLines = logContent.split("\n").filter((line) => line.trim() !== "")

    if (logLines.length === 0) {
      return {
        status: "idle",
        message: "No scraper activity found",
        lastRun: null,
      }
    }

    // Parse the most recent log entries
    const lastLine = logLines[logLines.length - 1]
    const timestampMatch = lastLine.match(/\[(.*?)\]/)
    const lastTimestamp = timestampMatch ? timestampMatch[1] : null

    // Check if the last log contains completion message
    const isCompleted = lastLine.includes("completed successfully")
    const isRunning = lastLine.includes("Starting") || lastLine.includes("Processing")
    const hasError = lastLine.includes("Error")

    let status = "unknown"
    if (isCompleted) status = "completed"
    else if (hasError) status = "error"
    else if (isRunning) status = "running"

    return {
      status,
      message: lastLine.replace(/\[.*?\]\s/, ""),
      lastRun: lastTimestamp,
      recentLogs: logLines.slice(-10), // Return the 10 most recent log lines
    }
  } catch (error) {
    return {
      status: "error",
      message: `Error getting scraper status: ${error.message}`,
      error: error.message,
    }
  }
}

// Allow direct execution for testing
if (process.argv[2] === "--check") {
  const cityName = process.argv[3] || "Leeds"

  checkDatabaseExists(cityName)
    .then((exists) => console.log(`Database ${cityName} exists: ${exists}`))
    .catch((err) => console.error("Error:", err))
}

if (process.argv[2] === "--run") {
  const cityName = process.argv[3] || "Leeds"
  const postcodeArea = process.argv[4] || "LS"
  const keyword = process.argv[5] || "restaurant"

  runScrapeWorkflow(cityName, postcodeArea, keyword)
    .then((result) => console.log(JSON.stringify(result, null, 2)))
    .catch((err) => console.error("Error:", err))
}
