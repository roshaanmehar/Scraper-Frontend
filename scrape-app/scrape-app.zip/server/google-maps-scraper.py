#!/usr/bin/env python3
# ────────────────────────────────────────────────────────────────
#  v7_address_fix.py  –  Leeds Google‑Maps "card‑first" restaurant scraper
#  Created 2025‑05‑03
#
#  • Subsector work‑queue:  Leeds.subsector_queue
#  • Business store:        Leeds.restaurants     (unique + sparse on phonenumber)
#  • Card‑first workflow:   click result → wait for card (name & phone) → scrape →
#                           close card → pause → next tile → scroll when out of tiles
#  • Enhanced address and website extraction with multiple fallback methods
#  • Processes each subsector independently, tracking processed cards per subsector
#  • Upserts each record immediately after scraping
# ────────────────────────────────────────────────────────────────

import argparse
import json
import logging
import os
import random
import re
import sys
import time
import traceback
from datetime import datetime
from typing import List, Tuple, Dict, Any, Optional, Set

from bson import ObjectId
from pymongo import MongoClient, ReturnDocument, ASCENDING
from pymongo.errors import PyMongoError, DuplicateKeyError, ServerSelectionTimeoutError, ConnectionFailure
from selenium.common.exceptions import (
    NoSuchElementException,
    TimeoutException,
    StaleElementReferenceException,
    WebDriverException,
    ElementClickInterceptedException,
    ElementNotInteractableException,
    InvalidSessionIdException
)
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium import webdriver

# ───────────────── Logging ──────────────────────
# Fix for Windows encoding issues - use ASCII-compatible arrow instead of Unicode
ARROW = "->"  # Replace Unicode arrow with ASCII compatible version

# Configure logging with proper encoding for Windows
logging.basicConfig(
    level=os.getenv("LOGLEVEL", "INFO"),
    format="[%(asctime)s] %(levelname)-5s – %(message)s",
    datefmt="%H:%M:%S",
    handlers=[
        # Force UTF-8 encoding for console output
        logging.StreamHandler(sys.stdout),
        # File handler with UTF-8 encoding
        logging.FileHandler("scraper.log", encoding="utf-8")
    ]
)
log = logging.getLogger(__name__)

# ─────────────────── Tunables & Delays ──────────────
# Optimized delays - reduced but still human-like
SEARCH_DELAY_MIN, SEARCH_DELAY_MAX = 0.5, 1.0
CLICK_WAIT_MIN,   CLICK_WAIT_MAX   = 1.0, 1.5
CLOSE_WAIT_MIN,   CLOSE_WAIT_MAX   = 0.5, 0.8
SCROLL_WAIT_MIN,  SCROLL_WAIT_MAX  = 2.0, 3.0
SUBSECTOR_WAIT_MIN, SUBSECTOR_WAIT_MAX = 5.0, 8.0
PHONE_WAIT_TIME = 2.0  # Reduced wait time for phone numbers
ADDRESS_WAIT_TIME = 2.0  # Wait time for address to load
WEBSITE_WAIT_TIME = 2.0  # Wait time for website to load

MAX_SCROLL_ATTEMPTS = 12
RESULT_LIMIT = 120   # stop after this many cards
MAX_STALE_RETRIES = 3  # Maximum retries for stale element exceptions
PAGE_REFRESH_THRESHOLD = 3  # Refresh page after this many consecutive stale errors
MONGO_RETRY_ATTEMPTS = 3  # Number of times to retry MongoDB operations
MONGO_RETRY_DELAY = 1.0  # Seconds to wait between MongoDB retries
DRIVER_RESET_THRESHOLD = 10  # Reset driver after this many errors

SERVICE, CITY = "restaurants in", "leeds"

# ───────────── CSS Selectors & XPaths (user‑supplied) ─────────────
# Card pane
CARD_PANE_CSS = "#QA0Szd > div > div > div.w6VYqd > div.bJzME.Hu9e2e.tTVLSc > div"
CARD_PANE_XPATH = '//*[@id="QA0Szd"]/div/div/div[1]/div[3]/div'

# Business name
NAME_CSS = "#QA0Szd > div > div > div.w6VYqd > div.bJzME.Hu9e2e.tTVLSc > div > div.e07Vkf.kA9KIf > div > div > div.m6QErb.DxyBCb.kA9KIf.dS8AEf.XiKgde > div.TIHn2 > div > div.lMbq3e > div:nth-child(1) > h1"
NAME_XPATH = '//*[@id="QA0Szd"]/div/div/div[1]/div[3]/div/div[1]/div/div/div[2]/div[2]/div/div[1]/div[1]/h1'

# Rating
RATING_CSS = "#QA0Szd > div > div > div.w6VYqd > div.bJzME.Hu9e2e.tTVLSc > div > div.e07Vkf.kA9KIf > div > div > div.m6QErb.DxyBCb.kA9KIf.dS8AEf.XiKgde > div.TIHn2 > div > div.lMbq3e > div.LBgpqf > div > div.fontBodyMedium.dmRWX > div.F7nice > span:nth-child(1) > span:nth-child(1)"
RATING_XPATH = '//*[@id="QA0Szd"]/div/div/div[1]/div[3]/div/div[1]/div/div/div[2]/div[2]/div/div[1]/div[2]/div/div[1]/div[2]/span[1]/span[1]'

# Number of reviews
REVIEWS_CSS = "#QA0Szd > div > div > div.w6VYqd > div.bJzME.Hu9e2e.tTVLSc > div > div.e07Vkf.kA9KIf > div > div > div.m6QErb.DxyBCb.kA9KIf.dS8AEf.XiKgde > div.TIHn2 > div > div.lMbq3e > div.LBgpqf > div > div.fontBodyMedium.dmRWX > div.F7nice > span:nth-child(2) > span > span"
REVIEWS_XPATH = '//*[@id="QA0Szd"]/div/div/div[1]/div[3]/div/div[1]/div/div/div[2]/div[2]/div/div[1]/div[2]/div/div[1]/div[2]/span[2]/span/span'

# Address - multiple selectors for better reliability
ADDRESS_SELECTORS = [
    # Primary selectors
    "#QA0Szd > div > div > div.w6VYqd > div.bJzME.Hu9e2e.tTVLSc > div > div.e07Vkf.kA9KIf > div > div > div.m6QErb.DxyBCb.kA9KIf.dS8AEf.XiKgde > div:nth-child(9) > div:nth-child(3) > button > div > div.rogA2c > div.Io6YTe.fontBodyMedium.kR99db.fdkmkc",
    '//*[@id="QA0Szd"]/div/div/div[1]/div[3]/div/div[1]/div/div/div[2]/div[9]/div[3]/button/div/div[2]/div[1]',
    
    # Fallback selectors
    "button[data-item-id='address'] div.Io6YTe",
    "button[aria-label*='address'] div.Io6YTe",
    "button[data-tooltip*='address'] div.Io6YTe",
    "div[role='button'][data-item-id*='address'] div.Io6YTe",
    "div.rogA2c div.Io6YTe.fontBodyMedium",
    
    # Generic selectors
    "div.Io6YTe.fontBodyMedium:not(:empty)"
]

# Website - multiple selectors for better reliability
WEBSITE_SELECTORS = [
    # Primary selectors
    "#QA0Szd > div > div > div.w6VYqd > div.bJzME.Hu9e2e.tTVLSc > div > div.e07Vkf.kA9KIf > div > div > div.m6QErb.DxyBCb.kA9KIf.dS8AEf.XiKgde > div:nth-child(9) > div:nth-child(8) > a > div > div.rogA2c.ITvuef > div.Io6YTe.fontBodyMedium.kR99db.fdkmkc",
    '//*[@id="QA0Szd"]/div/div/div[1]/div[3]/div/div[1]/div/div/div[2]/div[9]/div[8]/a/div/div[2]/div[1]',
    
    # Fallback selectors
    "a[data-item-id='authority']",
    "a[aria-label*='website']",
    "a[data-tooltip*='website']",
    "a[href^='https']:not([href*='google'])",
    
    # Generic selectors
    "div.m6QErb a[target='_blank']"
]

# Phone number - prioritized selectors (most reliable first)
PHONE_SELECTORS = [
    "button[data-item-id='phone:tel'] div.Io6YTe",
    "#QA0Szd > div > div > div.w6VYqd > div.bJzME.Hu9e2e.tTVLSc > div > div.e07Vkf.kA9KIf > div > div > div.m6QErb.DxyBCb.kA9KIf.dS8AEf.XiKgde > div:nth-child(9) > div:nth-child(9) > button > div > div.rogA2c > div.Io6YTe.fontBodyMedium.kR99db.fdkmkc",
    "button[aria-label*='phone'] div.Io6YTe",
    "button[data-tooltip='Copy phone number'] div.Io6YTe"
]

# Tile name selector - to get name from tile before clicking
TILE_NAME_CSS = "div.qBF1Pd.fontHeadlineSmall"

# Fallback selectors (original ones)
FALLBACK_NAME = "h1.DUwDvf"
FALLBACK_STARS = "span.Aq14fc"
FALLBACK_REVIEWS = "span.z5jxId"

# ───────────────── JSON Encoder for MongoDB ───────────────────
class MongoJSONEncoder(json.JSONEncoder):
    """Custom JSON encoder that can handle MongoDB ObjectId."""
    def default(self, obj):
        if isinstance(obj, ObjectId):
            return str(obj)  # Convert ObjectId to string
        if isinstance(obj, datetime):
            return obj.isoformat()  # Convert datetime to ISO format
        return super().default(obj)

# ───────────────── CLI Parsing ───────────────────────
def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser("Scrape Google‑Maps restaurants (card‑first)")
    p.add_argument("--start", type=int, help="Start queue index (inclusive)")
    p.add_argument("--end",   type=int, help="End   queue index (inclusive)")
    p.add_argument("--headless", action="store_true", help="Run Chrome headless")
    p.add_argument("--subsector", type=str, help="Scrape specific subsector")
    p.add_argument("--debug", action="store_true", help="Enable debug logging")
    p.add_argument("--fast", action="store_true", help="Use faster scraping (less human-like)")
    p.add_argument("--mongo-uri", type=str, default="mongodb://localhost:27017", 
                   help="MongoDB connection URI")
    return p.parse_args()

# ───────────────── MongoDB Setup ─────────────────────
def setup_mongodb(mongo_uri: str) -> Tuple[MongoClient, Any, Any]:
    """Set up MongoDB connection and collections with proper error handling."""
    for attempt in range(MONGO_RETRY_ATTEMPTS):
        try:
            # Use a longer timeout for initial connection
            client = MongoClient(mongo_uri, 
                                serverSelectionTimeoutMS=10000,
                                connectTimeoutMS=20000,
                                socketTimeoutMS=45000,
                                maxPoolSize=50,
                                retryWrites=True)
            
            # Test connection
            client.admin.command('ping')
            log.info("Connected to MongoDB successfully")
            
            db = client["Leeds"]
            queue_col = db["subsector_queue"]
            rest_col = db["restaurants"]
            
            # Create indexes
            queue_col.create_index(
                [("scrapedsuccessfully", ASCENDING), ("processing", ASCENDING)], 
                background=True
            )
            log.info("Created queue index")
            
            # Create sparse unique index on phonenumber
            try:
                rest_col.create_index(
                    [("phonenumber", ASCENDING)], 
                    unique=True, 
                    sparse=True, 
                    background=True
                )
                # Also create index on businessname for faster lookups
                rest_col.create_index([("businessname", ASCENDING)], background=True)
                # Create compound index on subsector and businessname
                rest_col.create_index([
                    ("subsector", ASCENDING),
                    ("businessname", ASCENDING)
                ], background=True)
                log.info("Created indexes")
            except PyMongoError as e:
                log.warning("Index creation issue (continuing anyway): %s", e)
            
            return client, queue_col, rest_col
            
        except (ServerSelectionTimeoutError, ConnectionFailure) as e:
            if attempt < MONGO_RETRY_ATTEMPTS - 1:
                log.warning("MongoDB connection failed (attempt %d/%d): %s. Retrying...", 
                           attempt + 1, MONGO_RETRY_ATTEMPTS, e)
                time.sleep(MONGO_RETRY_DELAY * (attempt + 1))  # Exponential backoff
            else:
                log.critical("MongoDB setup failed after %d attempts: %s", MONGO_RETRY_ATTEMPTS, e)
                sys.exit(1)
        except Exception as e:
            log.critical("MongoDB setup failed with unexpected error: %s", e)
            sys.exit(1)

# ───────────────── File Output ───────────────────────
OUT_DIR = "business_data"
os.makedirs(OUT_DIR, exist_ok=True)

def save_json(code: str, rows: List[dict]) -> bool:
    """Save records to JSON file with custom encoder for MongoDB types.
    Returns True if successful, False otherwise."""
    if not rows:
        log.warning("%s %s No records to save to JSON", code, ARROW)
        return False
        
    try:
        # Clean records for JSON serialization
        clean_rows = []
        for row in rows:
            clean_row = {}
            for k, v in row.items():
                if k != "_id":  # Skip MongoDB _id field
                    clean_row[k] = v
            clean_rows.append(clean_row)
            
        fp = os.path.join(OUT_DIR, f"leeds_{code}.json")
        with open(fp, "w", encoding="utf-8") as fh:
            json.dump(clean_rows, fh, indent=4, cls=MongoJSONEncoder)
        log.info("%s %s JSON saved %s %s (%d records)", code, ARROW, ARROW, fp, len(clean_rows))
        return True
    except Exception as e:
        log.error("%s %s Failed to save JSON: %s", code, ARROW, e)
        return False

def save_csv(code: str, rows: List[dict]) -> bool:
    """Save records to CSV file.
    Returns True if successful, False otherwise."""
    if not rows:
        log.warning("%s %s No records to save to CSV", code, ARROW)
        return False
        
    try:
        import csv
        
        fp = os.path.join(OUT_DIR, f"leeds_{code}.csv")
        
        # Get all possible field names from all records
        fieldnames = set()
        for row in rows:
            fieldnames.update(row.keys())
        
        # Remove MongoDB _id field if present
        if "_id" in fieldnames:
            fieldnames.remove("_id")
            
        fieldnames = sorted(list(fieldnames))
        
        with open(fp, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=fieldnames)
            writer.writeheader()
            
            for row in rows:
                # Create a clean row without _id
                clean_row = {k: v for k, v in row.items() if k != "_id"}
                writer.writerow(clean_row)
                
        log.info("%s %s CSV saved %s %s (%d records)", code, ARROW, ARROW, fp, len(rows))
        return True
    except Exception as e:
        log.error("%s %s Failed to save CSV: %s", code, ARROW, e)
        return False

# ───────────────── Selenium Driver ───────────────────
def make_driver(headless: bool) -> webdriver.Chrome:
    ua = random.choice(
        [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/121.0.0.0 Safari/537.36",
        ]
    )
    opts = webdriver.ChromeOptions()
    opts.add_argument(f"user-agent={ua}")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    
    # Performance optimizations
    opts.add_argument("--disable-extensions")
    opts.add_argument("--disable-gpu")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--no-sandbox")
    
    # Disable WebGL to prevent GPU errors
    opts.add_argument("--disable-webgl")
    opts.add_argument("--disable-3d-apis")
    
    # Disable software rendering fallback warnings
    opts.add_argument("--disable-software-rasterizer")
    
    # Disable logging
    opts.add_argument("--log-level=3")
    opts.add_experimental_option('excludeSwitches', ['enable-logging'])
    
    if headless:
        opts.add_argument("--headless=new")
        opts.add_argument("--blink-settings=imagesEnabled=false")
    
    # Set page load strategy to eager for faster loading
    opts.page_load_strategy = 'eager'
    
    return webdriver.Chrome(options=opts)

# ───────────────── Helper Utilities ──────────────────
def rdelay(a: float, b: float, fast_mode: bool = False):
    """Random delay with option for fast mode"""
    if fast_mode:
        time.sleep(random.uniform(a * 0.5, b * 0.5))  # 50% faster in fast mode
    else:
        time.sleep(random.uniform(a, b))

def digits(text: str) -> str:
    return re.sub(r"\D", "", text or "")

def safe_text_with_fallbacks(driver: webdriver.Chrome, css: str, xpath: str, fallback: str = None) -> str:
    """Try to get text using CSS, then XPath, then fallback selector."""
    for attempt in range(MAX_STALE_RETRIES):
        try:
            try:
                return driver.find_element(By.CSS_SELECTOR, css).text.strip()
            except NoSuchElementException:
                try:
                    return driver.find_element(By.XPATH, xpath).text.strip()
                except NoSuchElementException:
                    if fallback:
                        try:
                            return driver.find_element(By.CSS_SELECTOR, fallback).text.strip()
                        except NoSuchElementException:
                            return ""
                    return ""
        except StaleElementReferenceException:
            if attempt < MAX_STALE_RETRIES - 1:
                time.sleep(0.5)
                continue
            else:
                return ""
        except Exception:
            return ""
    return ""

def get_tile_name(tile) -> str:
    """Extract the name from a tile element before clicking it."""
    for attempt in range(MAX_STALE_RETRIES):
        try:
            name_element = tile.find_element(By.CSS_SELECTOR, TILE_NAME_CSS)
            return name_element.text.strip()
        except (NoSuchElementException, StaleElementReferenceException):
            if attempt < MAX_STALE_RETRIES - 1:
                time.sleep(0.5)
                continue
            else:
                return ""
    return ""

def extract_address(driver: webdriver.Chrome, debug: bool = False) -> str:
    """Extract address using multiple selectors and methods.
    Returns the address as a string or "N/A" if not found."""
    
    # Wait a moment for address to load
    time.sleep(ADDRESS_WAIT_TIME)
    
    # Try all selectors in order
    for selector in ADDRESS_SELECTORS:
        try:
            # Determine if it's XPath or CSS
            by_method = By.XPATH if selector.startswith('/') else By.CSS_SELECTOR
            
            elements = driver.find_elements(by_method, selector)
            for element in elements:
                text = element.text.strip()
                if debug:
                    log.debug("Found potential address element: %s", text)
                
                # Check if text looks like an address (contains numbers and letters)
                if re.search(r'\d', text) and len(text) > 5:
                    if debug:
                        log.debug("Extracted address: %s", text)
                    return text
        except Exception as e:
            if debug:
                log.debug("Error with address selector %s: %s", selector, e)
            continue
    
    # If we still don't have an address, try JavaScript
    try:
        address = driver.execute_script("""
            // Try to find address elements
            var addressElements = [
                // Buttons with address
                ...Array.from(document.querySelectorAll('button[data-item-id="address"] div.Io6YTe')),
                ...Array.from(document.querySelectorAll('button[aria-label*="address"] div.Io6YTe')),
                // Any element with address text
                ...Array.from(document.querySelectorAll('div.Io6YTe.fontBodyMedium')),
                // Any element with a location icon
                ...Array.from(document.querySelectorAll('div.Io6YTe'))
            ];
            
            for (let el of addressElements) {
                if (el && el.textContent && el.textContent.trim().length > 5 && /\\d/.test(el.textContent)) {
                    return el.textContent.trim();
                }
            }
            
            return "";
        """)
        
        if address:
            if debug:
                log.debug("Extracted address via JavaScript: %s", address)
            return address
    except Exception as e:
        if debug:
            log.debug("JavaScript address extraction error: %s", e)
    
    return "N/A"

def extract_website(driver: webdriver.Chrome, debug: bool = False) -> str:
    """Extract website URL using multiple selectors and methods.
    Returns the website URL as a string or "N/A" if not found."""
    
    # Wait a moment for website to load
    time.sleep(WEBSITE_WAIT_TIME)
    
    # Try all selectors in order
    for selector in WEBSITE_SELECTORS:
        try:
            # Determine if it's XPath or CSS
            by_method = By.XPATH if selector.startswith('/') else By.CSS_SELECTOR
            
            elements = driver.find_elements(by_method, selector)
            for element in elements:
                # First try to get href attribute if it's an anchor
                if element.tag_name == 'a':
                    href = element.get_attribute('href')
                    if href and 'google.com' not in href and href.startswith('http'):
                        if debug:
                            log.debug("Extracted website URL from href: %s", href)
                        return href
                
                # Then try to get text
                text = element.text.strip()
                if debug:
                    log.debug("Found potential website element: %s", text)
                
                # Check if text looks like a website URL
                if text and ('.' in text) and ('http' in text or 'www' in text):
                    if debug:
                        log.debug("Extracted website from text: %s", text)
                    return text
        except Exception as e:
            if debug:
                log.debug("Error with website selector %s: %s", selector, e)
            continue
    
    # If we still don't have a website, try JavaScript
    try:
        website = driver.execute_script("""
            // Try to find website elements
            var websiteElements = [
                // Direct website links
                ...Array.from(document.querySelectorAll('a[data-item-id="authority"]')),
                ...Array.from(document.querySelectorAll('a[aria-label*="website"]')),
                // Any external link that's not to Google
                ...Array.from(document.querySelectorAll('a[target="_blank"]'))
            ];
            
            for (let el of websiteElements) {
                if (el && el.href && el.href.startsWith('http') && !el.href.includes('google.com')) {
                    return el.href;
                }
            }
            
            // Try to find website text
            var textElements = document.querySelectorAll('div.Io6YTe.fontBodyMedium');
            for (let el of textElements) {
                if (el && el.textContent && (el.textContent.includes('http') || el.textContent.includes('www'))) {
                    return el.textContent.trim();
                }
            }
            
            return "";
        """)
        
        if website:
            if debug:
                log.debug("Extracted website via JavaScript: %s", website)
            return website
    except Exception as e:
        if debug:
            log.debug("JavaScript website extraction error: %s", e)
    
    return "N/A"

def extract_phone_number(driver: webdriver.Chrome, debug: bool = False) -> Optional[int]:
    """Extract phone number using optimized selectors.
    Returns the phone number as an integer or None if not found."""
    
    # Wait a moment for phone to load
    time.sleep(PHONE_WAIT_TIME)
    
    # Try the most reliable selectors first
    for selector in PHONE_SELECTORS:
        try:
            elements = driver.find_elements(By.CSS_SELECTOR, selector)
            for element in elements:
                text = element.text.strip()
                if debug:
                    log.debug("Found potential phone element: %s", text)
                
                # Check if text looks like a phone number
                if re.search(r'\d', text):  # Contains at least one digit
                    digits_only = digits(text)
                    if digits_only and len(digits_only) >= 5:  # Reasonable phone number length
                        if debug:
                            log.debug("Extracted phone digits: %s", digits_only)
                        return int(digits_only)
        except Exception as e:
            if debug:
                log.debug("Error with selector %s: %s", selector, e)
            continue
    
    # If we still don't have a phone number, try JavaScript
    try:
        phone_text = driver.execute_script("""
            // Try to find phone elements
            var phoneElements = [
                // Direct phone buttons
                ...Array.from(document.querySelectorAll('button[data-item-id="phone:tel"] div.Io6YTe')),
                ...Array.from(document.querySelectorAll('button[aria-label*="phone"] div.Io6YTe')),
                // Any element that might contain a phone number
                ...Array.from(document.querySelectorAll('div.Io6YTe.fontBodyMedium'))
            ];
            
            for (let el of phoneElements) {
                if (el && el.textContent && /\\d/.test(el.textContent)) {
                    return el.textContent.trim();
                }
            }
            
            return "";
        """)
        
        if phone_text:
            digits_only = digits(phone_text)
            if digits_only and len(digits_only) >= 5:
                if debug:
                    log.debug("Extracted phone via JavaScript: %s", digits_only)
                return int(digits_only)
    except Exception as e:
        if debug:
            log.debug("JavaScript phone extraction error: %s", e)
    
    return None

def dismiss_banners(driver: webdriver.Chrome):
    """Close GDPR or consent banners if present."""
    for label in ("Reject all", "Accept all", "I agree", "Dismiss"):
        try:
            btn = WebDriverWait(driver, 3).until(
                EC.element_to_be_clickable(
                    (By.CSS_SELECTOR, f'button[aria-label="{label}"]')
                )
            )
            btn.click()
            log.debug("✕ dismissed popup (%s)", label)
            return
        except TimeoutException:
            continue

def scroll_results_feed(driver: webdriver.Chrome, code: str) -> int:
    """Scroll the results feed down once and return new tile count."""
    for attempt in range(MAX_STALE_RETRIES):
        try:
            # Try to find the feed element
            try:
                feed = WebDriverWait(driver, 5).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, 'div[role="feed"]'))
                )
            except TimeoutException:
                # If we can't find the feed, try to scroll the whole page
                driver.execute_script("window.scrollBy(0, 500)")
                time.sleep(1)
                return len(driver.find_elements(By.CSS_SELECTOR, "div.Nv2PK"))
            
            # Scroll the feed
            driver.execute_script(
                "arguments[0].scrollTop = arguments[0].scrollHeight", feed
            )
            rdelay(SCROLL_WAIT_MIN, SCROLL_WAIT_MAX)
            
            # Count tiles
            count = len(driver.find_elements(By.CSS_SELECTOR, "div.Nv2PK"))
            log.info("%s %s scrolled feed (tiles now %d)", code, ARROW, count)
            return count
            
        except StaleElementReferenceException:
            if attempt < MAX_STALE_RETRIES - 1:
                log.debug("%s %s Stale element during scroll, retrying", code, ARROW)
                time.sleep(1)
                continue
            else:
                # If we keep getting stale elements, try JavaScript scrolling
                try:
                    driver.execute_script("""
                        var feeds = document.querySelectorAll('div[role="feed"]');
                        if (feeds.length > 0) {
                            feeds[0].scrollTop = feeds[0].scrollHeight;
                        } else {
                            window.scrollBy(0, 500);
                        }
                    """)
                    time.sleep(2)
                    return len(driver.find_elements(By.CSS_SELECTOR, "div.Nv2PK"))
                except Exception as e:
                    log.error("%s %s JavaScript scroll error: %s", code, ARROW, e)
                    return 0
        except Exception as e:
            log.error("%s %s scroll error: %s", code, ARROW, e)
            return 0
    
    return 0

def safe_click_tile(driver: webdriver.Chrome, tile, code: str, tile_idx: int, total_tiles: int) -> bool:
    """Safely click a tile with retry logic for stale elements.
    Returns True if successful, False otherwise."""
    for attempt in range(MAX_STALE_RETRIES):
        try:
            log.debug("%s %s Clicking tile %d/%d (attempt %d/%d)", 
                     code, ARROW, tile_idx + 1, total_tiles, attempt + 1, MAX_STALE_RETRIES)
            
            # First make sure the tile is in view
            driver.execute_script("arguments[0].scrollIntoView({block: 'center', behavior: 'smooth'});", tile)
            time.sleep(0.5)  # Short pause to let the UI stabilize
            
            # Try direct click first
            try:
                WebDriverWait(driver, 5).until(EC.element_to_be_clickable(tile))
                tile.click()
                return True
            except (ElementClickInterceptedException, ElementNotInteractableException):
                # If direct click fails, try ActionChains
                actions = ActionChains(driver)
                actions.move_to_element(tile).pause(0.25).click().perform()
                return True
            except Exception:
                # If all else fails, try JavaScript click
                driver.execute_script("arguments[0].click();", tile)
                return True
                
        except StaleElementReferenceException:
            if attempt < MAX_STALE_RETRIES - 1:
                log.debug("%s %s Stale element, retrying (%d/%d)", 
                         code, ARROW, attempt + 1, MAX_STALE_RETRIES)
                time.sleep(0.5)  # Short pause before retry
            else:
                log.debug("%s %s Stale element, max retries reached", code, ARROW)
                return False
        except Exception as e:
            log.debug("%s %s Click error: %s", code, ARROW, e)
            return False
    
    return False

def safe_close_card(driver: webdriver.Chrome) -> bool:
    """Safely close the card with retry logic.
    Returns True if successful, False otherwise."""
    for attempt in range(MAX_STALE_RETRIES):
        try:
            actions = ActionChains(driver)
            actions.send_keys(Keys.ESCAPE).perform()
            return True
        except Exception as e:
            if attempt < MAX_STALE_RETRIES - 1:
                log.debug("Error closing card, retrying: %s", e)
                time.sleep(0.5)
            else:
                log.debug("Failed to close card after %d attempts: %s", MAX_STALE_RETRIES, e)
                # Try JavaScript fallback
                try:
                    driver.execute_script("""
                        document.querySelectorAll('button[aria-label="Back"]').forEach(b => b.click());
                        document.querySelectorAll('button[jsaction*="close"]').forEach(b => b.click());
                        document.dispatchEvent(new KeyboardEvent('keydown', {'key': 'Escape'}));
                    """)
                    return True
                except:
                    return False
    
    return False

def is_driver_alive(driver: webdriver.Chrome) -> bool:
    """Check if the driver is still alive and responsive."""
    try:
        # Try to get the current URL - this will fail if the driver is dead
        driver.current_url
        return True
    except (InvalidSessionIdException, WebDriverException):
        return False
    except Exception:
        return False

# ────────── MongoDB Insert/Update Functions ──────────
def check_phone_exists(rest_col, phone_number: int) -> bool:
    """Check if a phone number already exists in MongoDB.
    Returns True if it exists, False otherwise."""
    if not phone_number:
        return False
        
    for attempt in range(MONGO_RETRY_ATTEMPTS):
        try:
            count = rest_col.count_documents({"phonenumber": phone_number})
            return count > 0
        except PyMongoError as e:
            if attempt < MONGO_RETRY_ATTEMPTS - 1:
                log.warning("MongoDB error checking phone (attempt %d/%d): %s. Retrying...", 
                           attempt + 1, MONGO_RETRY_ATTEMPTS, e)
                time.sleep(MONGO_RETRY_DELAY * (attempt + 1))  # Exponential backoff
            else:
                log.error("MongoDB error after %d attempts: %s", MONGO_RETRY_ATTEMPTS, e)
                return False
        except Exception as e:
            log.error("Unexpected error checking phone: %s", e)
            return False
    
    return False

def insert_record(rest_col, record: dict) -> bool:
    """Insert a single record into MongoDB, handling uniqueness constraints.
    Returns True if inserted successfully."""
    # First check if phone number already exists
    if record.get("phonenumber") and check_phone_exists(rest_col, record["phonenumber"]):
        log.debug("Skipping insert - phone number already exists: %s", record.get("phonenumber"))
        return True  # Consider it successful since we're intentionally skipping
    
    for attempt in range(MONGO_RETRY_ATTEMPTS):
        try:
            # If record has a phone number, use it as a unique key
            if record.get("phonenumber"):
                rest_col.update_one(
                    {"phonenumber": record["phonenumber"]},
                    {"$set": record},
                    upsert=True
                )
                log.debug("Inserted/updated record with phone: %s", record.get("phonenumber"))
            else:
                # For records without phone numbers, use business name as key
                rest_col.update_one(
                    {"businessname": record["businessname"]},
                    {"$set": record},
                    upsert=True
                )
                log.debug("Inserted/updated record without phone: %s", record.get("businessname"))
            return True
        except DuplicateKeyError:
            # This shouldn't happen with update_one + upsert, but just in case
            log.warning("Duplicate key for record: %s", record.get("businessname"))
            return True  # Still consider it successful since the record exists
        except PyMongoError as e:
            if attempt < MONGO_RETRY_ATTEMPTS - 1:
                log.warning("MongoDB error (attempt %d/%d): %s. Retrying...", 
                           attempt + 1, MONGO_RETRY_ATTEMPTS, e)
                time.sleep(MONGO_RETRY_DELAY * (attempt + 1))  # Exponential backoff
            else:
                log.error("MongoDB error after %d attempts: %s", MONGO_RETRY_ATTEMPTS, e)
                return False
        except Exception as e:
            log.error("Unexpected error: %s", e)
            return False
    
    return False

# ────────────── Scrape One Subsector ────────────────
def scrape_subsector(
    doc: dict, driver: webdriver.Chrome, rest_col, debug: bool = False, fast_mode: bool = False
) -> Tuple[List[dict], int]:
    code = doc["subsector"].strip()
    log.info("Starting scrape for subsector: %s", code)

    # 1 · open Google Maps and submit search
    try:
        driver.get("https://www.google.com/maps")
        dismiss_banners(driver)

        search_box = WebDriverWait(driver, 15).until(
            EC.element_to_be_clickable((By.ID, "searchboxinput"))
        )
        rdelay(SEARCH_DELAY_MIN, SEARCH_DELAY_MAX, fast_mode)
        search_box.clear()
        query = f"{SERVICE} {code} {CITY}"
        search_box.send_keys(query)
        rdelay(SEARCH_DELAY_MIN, SEARCH_DELAY_MAX, fast_mode)
        search_box.send_keys(Keys.ENTER)
        log.info("%s %s search query launched", code, ARROW)

        try:
            WebDriverWait(driver, 20).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "div.Nv2PK"))
            )
        except TimeoutException:
            log.error("%s %s No results found", code, ARROW)
            return [], 0
    except Exception as e:
        log.error("%s %s Error during search setup: %s", code, ARROW, e)
        return [], 0

    total_cards, scroll_attempts = 0, 0
    records: List[dict] = []
    
    # Track processed businesses to avoid duplicates WITHIN THIS SUBSECTOR ONLY
    # This is reset for each new subsector
    processed_businesses: Set[str] = set()
    processed_phones: Set[int] = set()
    
    # Track consecutive stale element errors
    consecutive_stale_errors = 0
    total_errors = 0

    # 2 · iterate visible tiles, open each card
    while total_cards < RESULT_LIMIT and scroll_attempts < MAX_SCROLL_ATTEMPTS:
        # Check if we need to refresh the page due to too many stale errors
        if consecutive_stale_errors >= PAGE_REFRESH_THRESHOLD:
            log.warning("%s %s Too many consecutive stale errors, refreshing page", code, ARROW)
            try:
                driver.refresh()
                time.sleep(3)  # Wait for page to reload
                consecutive_stale_errors = 0
                
                # Re-enter search query after refresh
                search_box = WebDriverWait(driver, 15).until(
                    EC.element_to_be_clickable((By.ID, "searchboxinput"))
                )
                search_box.clear()
                search_box.send_keys(query)
                search_box.send_keys(Keys.ENTER)
                
                # Wait for results to load
                WebDriverWait(driver, 20).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, "div.Nv2PK"))
                )
            except Exception as e:
                log.error("%s %s Error during page refresh: %s", code, ARROW, e)
                scroll_attempts += 1
            continue
            
        # Check if driver is still alive
        if not is_driver_alive(driver):
            log.error("%s %s Driver session is no longer valid", code, ARROW)
            return records, total_cards
            
        # Check if we need to reset the driver due to too many errors
        if total_errors >= DRIVER_RESET_THRESHOLD:
            log.warning("%s %s Too many total errors, returning current results", code, ARROW)
            return records, total_cards
            
        # Get fresh tiles
        try:
            tiles = WebDriverWait(driver, 10).until(
                EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div.Nv2PK"))
            )
        except TimeoutException:
            log.warning("%s %s No tiles found, scrolling to find more", code, ARROW)
            scroll_attempts += 1
            scroll_results_feed(driver, code)
            continue
        except Exception as e:
            log.error("%s %s Error finding tiles: %s", code, ARROW, e)
            total_errors += 1
            scroll_attempts += 1
            continue

        if not tiles:
            scroll_attempts += 1
            scroll_results_feed(driver, code)
            continue

        log.info("%s %s Processing %d tiles", code, ARROW, len(tiles))
        
        # Track how many new tiles we process in this batch
        new_tiles_processed = 0
        
        for tile_idx, tile in enumerate(tiles):
            if total_cards >= RESULT_LIMIT:
                break
                
            # Try to get the business name from the tile before clicking
            tile_name = get_tile_name(tile)
            
            # Skip if we've already processed this business IN THIS SUBSECTOR
            if tile_name and tile_name in processed_businesses:
                log.debug("%s %s Skipping already processed in this subsector: %s", code, ARROW, tile_name)
                continue
                
            # Safely click tile with retry logic
            if not safe_click_tile(driver, tile, code, tile_idx, len(tiles)):
                consecutive_stale_errors += 1
                total_errors += 1
                log.debug("%s %s Failed to click tile, skipping", code, ARROW)
                continue
            else:
                consecutive_stale_errors = 0  # Reset counter on success

            # wait until card shows name using the new selectors
            try:
                WebDriverWait(driver, 12).until(
                    lambda d: (
                        d.find_elements(By.CSS_SELECTOR, NAME_CSS) or 
                        d.find_elements(By.XPATH, NAME_XPATH) or
                        d.find_elements(By.CSS_SELECTOR, FALLBACK_NAME)
                    )
                )
            except TimeoutException:
                log.debug("%s %s Card timeout, closing", code, ARROW)
                # close incomplete card and move on
                safe_close_card(driver)
                rdelay(CLOSE_WAIT_MIN, CLOSE_WAIT_MAX, fast_mode)
                continue
            except Exception as e:
                log.debug("%s %s Error waiting for card: %s", code, ARROW, e)
                safe_close_card(driver)
                rdelay(CLOSE_WAIT_MIN, CLOSE_WAIT_MAX, fast_mode)
                total_errors += 1
                continue

            rdelay(CLICK_WAIT_MIN, CLICK_WAIT_MAX, fast_mode)

            # Extract data using the new selectors with fallbacks
            name = safe_text_with_fallbacks(driver, NAME_CSS, NAME_XPATH, FALLBACK_NAME)
            
            # Skip if we've already processed this business IN THIS SUBSECTOR
            if name in processed_businesses:
                log.debug("%s %s Skipping already processed in this subsector (by card name): %s", code, ARROW, name)
                safe_close_card(driver)
                rdelay(CLOSE_WAIT_MIN, CLOSE_WAIT_MAX, fast_mode)
                continue
                
            stars = safe_text_with_fallbacks(driver, RATING_CSS, RATING_XPATH, FALLBACK_STARS) or "N/A"
            rev_raw = safe_text_with_fallbacks(driver, REVIEWS_CSS, REVIEWS_XPATH, FALLBACK_REVIEWS)
            reviews = int(re.sub(r"[^\d]", "", rev_raw)) if rev_raw else 0
            
            # Enhanced address extraction with multiple methods
            address = extract_address(driver, debug) or "N/A"
            
            # Enhanced website extraction with multiple methods
            website = extract_website(driver, debug) or "N/A"
            
            # Enhanced phone number extraction - optimized
            phone_int = extract_phone_number(driver, debug)
            
            # Skip if we've already processed this phone number IN THIS SUBSECTOR
            if phone_int and phone_int in processed_phones:
                log.debug("%s %s Skipping already processed in this subsector (by phone): %s - %s", 
                         code, ARROW, name, phone_int)
                safe_close_card(driver)
                rdelay(CLOSE_WAIT_MIN, CLOSE_WAIT_MAX, fast_mode)
                continue
                
            if address == str(phone_int):
                address = "N/A"

            record = {
                "subsector": code,
                "businessname": name,
                "address": address,
                "stars": stars,
                "numberofreviews": reviews,
                "website": website,
                "emailstatus": "pending" if website != "N/A" else "nowebsite",
                "email": "N/A",
                "scraped_at": datetime.now(),
            }
            
            # Only add phone number if it exists
            if phone_int:
                record["phonenumber"] = phone_int
                processed_phones.add(phone_int)  # Track in this subsector
                
            # Mark this business as processed IN THIS SUBSECTOR
            processed_businesses.add(name)
            
            # Insert record immediately after scraping into MongoDB
            # Only if phone number doesn't already exist in MongoDB
            log.info("%s %s Scraped: %s (phone: %s, address: %s, website: %s)", 
                     code, ARROW, name, 
                     phone_int if phone_int else "none",
                     address[:30] + "..." if len(address) > 30 else address,
                     website[:30] + "..." if len(website) > 30 else website)
            
            success = insert_record(rest_col, record)
            if success:
                records.append(record)
                total_cards += 1
                new_tiles_processed += 1
                
            # close card
            safe_close_card(driver)
            rdelay(CLOSE_WAIT_MIN, CLOSE_WAIT_MAX, fast_mode)

        # finished batch → scroll feed once
        prev = len(driver.find_elements(By.CSS_SELECTOR, "div.Nv2PK"))
        
        # If we didn't process any new tiles in this batch, scroll to find more
        if new_tiles_processed == 0:
            log.info("%s %s No new tiles processed in this batch, scrolling to find more", code, ARROW)
            scroll_attempts += 1
        else:
            log.info("%s %s Processed %d new tiles in this batch", code, ARROW, new_tiles_processed)
            scroll_attempts = 0
            
        new_count = scroll_results_feed(driver, code)
        if new_count <= prev:
            scroll_attempts += 1
        
        # Log progress
        log.info("%s %s Total unique businesses processed in this subsector: %d", code, ARROW, len(processed_businesses))

    log.info("%s %s cards scraped: %d (unique businesses in this subsector: %d)", 
             code, ARROW, total_cards, len(processed_businesses))
    return records, total_cards

# ─────────────── Processing Loop ────────────────
def process_subsectors(
    driver: webdriver.Chrome, args: argparse.Namespace, queue_col, rest_col
) -> int:
    # If specific subsector is provided, only process that one
    if args.subsector:
        log.info("Processing specific subsector: %s", args.subsector)
        
        def doc_iter():
            doc = queue_col.find_one({"subsector": args.subsector})
            if doc:
                yield doc
            else:
                # If subsector doesn't exist in queue, create it
                doc = {
                    "subsector": args.subsector,
                    "scrapedsuccessfully": False,
                    "processing": True
                }
                queue_col.insert_one(doc)
                yield doc
    
    # Process by index range
    elif args.start is not None and args.end is not None:
        log.info("Processing subsectors by index range: %d to %d", args.start, args.end)
        
        def doc_iter():
            for idx in range(args.start, args.end + 1):
                docs = list(
                    queue_col.find().sort("subsector", 1).skip(idx).limit(1)
                )
                if not docs:
                    continue
                doc = queue_col.find_one_and_update(
                    {"_id": docs[0]["_id"]},
                    {"$set": {"processing": True}},
                    return_document=ReturnDocument.AFTER
                )
                if doc:
                    yield doc
    
    # Process all unprocessed subsectors
    else:
        log.info("Processing all unprocessed subsectors")
        
        def doc_iter():
            while True:
                doc = queue_col.find_one_and_update(
                    {"scrapedsuccessfully": False, "processing": False},
                    {"$set": {"processing": True}},
                    return_document=ReturnDocument.AFTER
                )
                if not doc:
                    break
                yield doc

    processed = 0
    total_subsectors = 0
    
    # Count total subsectors for progress tracking
    if args.start is not None and args.end is not None:
        total_subsectors = args.end - args.start + 1
    elif args.subsector:
        total_subsectors = 1
    else:
        total_subsectors = queue_col.count_documents({"scrapedsuccessfully": False})
    
    log.info("Total subsectors to process: %d", total_subsectors)

    for doc in doc_iter():
        code = doc["subsector"]
        start = datetime.now()
        log.info("=" * 50)
        log.info("PROCESSING SUBSECTOR: %s (%d/%d)", code, processed + 1, total_subsectors)

        success = False
        rows = []
        card_count = 0
        
        for attempt in range(1, 4):
            try:
                # Check if driver is still alive, recreate if needed
                if not is_driver_alive(driver):
                    log.warning("Driver session is no longer valid, recreating...")
                    try:
                        driver.quit()
                    except:
                        pass
                    driver = make_driver(args.headless)
                
                rows, card_count = scrape_subsector(doc, driver, rest_col, args.debug, args.fast)
                if rows:
                    success = True
                    break
                else:
                    log.warning("%s %s attempt %d/3 returned no results", code, ARROW, attempt)
            except Exception as ex:
                log.error("%s %s attempt %d/3 failed: %s", code, ARROW, attempt, ex)
                log.error("Traceback: %s", traceback.format_exc())
                time.sleep(3)

        # Mark as not processing if we're going to skip it
        if not success:
            queue_col.update_one(
                {"_id": doc["_id"]}, 
                {"$set": {"processing": False}}
            )
            log.warning("%s %s skipped after failed attempts", code, ARROW)
            continue

        # write JSON after subsector is complete
        json_saved = save_json(code, rows)
        
        # Also save as CSV
        csv_saved = save_csv(code, rows)
        
        # Count unique records
        unique_count = len([r for r in rows if r.get("phonenumber")])
        total_count = len(rows)
        log.info("%s %s total records: %d (with phone: %d)", code, ARROW, total_count, unique_count)

        # mark subsector done
        queue_col.update_one(
            {"_id": doc["_id"]},
            {
                "$set": {
                    "scrapedsuccessfully": bool(rows),
                    "didresultsloadcompletely": card_count >= RESULT_LIMIT,
                    "totalrecordsfound": len(rows),
                    "totaluniquerecordsfound": unique_count,
                    "processing": False,
                    "json_saved": json_saved,
                    "csv_saved": csv_saved,
                    "completed_at": datetime.now()
                }
            },
        )

        processed += 1
        duration = datetime.now() - start
        progress_percent = (processed / total_subsectors) * 100 if total_subsectors > 0 else 0
        
        log.info(
            "%s %s done in %s • processed=%d/%d (%.1f%%)",
            code,
            ARROW,
            duration,
            processed,
            total_subsectors,
            progress_percent
        )
        log.info("=" * 50)
        
        # Only wait between subsectors if we have more to process
        if processed < total_subsectors:
            rdelay(SUBSECTOR_WAIT_MIN, SUBSECTOR_WAIT_MAX, args.fast)

    return processed

# ───────────────────── main ──────────────────────
def main():
    args = parse_args()
    
    # Set debug level if requested
    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)
    
    log.info("Starting Google Maps scraper")
    log.info("Arguments: %s", args)
    
    # Set up MongoDB
    client, queue_col, rest_col = setup_mongodb(args.mongo_uri)

    driver = None
    try:
        driver = make_driver(headless=args.headless)
        log.info("Chrome driver initialized successfully")
    except WebDriverException as e:
        log.critical("Chrome driver launch failed: %s", e)
        return

    try:
        total = process_subsectors(driver, args, queue_col, rest_col)
        log.info("✓ finished – subsectors processed: %d", total)
    except KeyboardInterrupt:
        log.warning("Interrupted by user.")
    except Exception as e:
        log.critical("Unhandled exception: %s", e)
        log.critical("Traceback: %s", traceback.format_exc())
    finally:
        try:
            if driver:
                driver.quit()
                log.info("Chrome driver closed")
        except Exception:
            pass
        
        try:
            client.close()
            log.info("MongoDB connection closed")
        except Exception:
            pass

# ─────────────────── Entry Point ──────────────────
if __name__ == "__main__":
    main()