#!/usr/bin/env python3
# Database checker script
# This script checks if a MongoDB database exists

import sys
import json
import os
import datetime
from pymongo import MongoClient

# Log function for tracking script execution
def log(message):
    timestamp = datetime.datetime.now().isoformat()
    log_message = f"[{timestamp}] {message}"
    print(log_message)
    
    # Ensure logs directory exists
    log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
    os.makedirs(log_dir, exist_ok=True)
    
    # Append to log file
    with open(os.path.join(log_dir, "scraper.log"), "a") as f:
        f.write(log_message + "\n")

def check_database_exists(city_name):
    # Get MongoDB URI from environment variable or use default
    mongodb_uri = os.environ.get("MONGODB_URI", "mongodb://localhost:27017")
    
    log(f"Connecting to MongoDB at {mongodb_uri}")
    client = MongoClient(mongodb_uri)
    
    try:
        # Get list of all databases
        database_names = client.list_database_names()
        log(f"Found databases: {', '.join(database_names)}")
        
        # Check if city_name database exists (case insensitive)
        city_name_lower = city_name.lower()
        exists = any(db.lower() == city_name_lower for db in database_names)
        
        log(f"Database '{city_name}' {'exists' if exists else 'does not exist'}")
        
        # Return result as JSON
        result = {
            "exists": exists,
            "message": f"Database '{city_name}' {'exists' if exists else 'does not exist'}"
        }
        
        print(json.dumps(result))
        return result
    
    except Exception as e:
        log(f"Error checking databases: {str(e)}")
        # Print error as JSON
        print(json.dumps({
            "exists": False,
            "message": f"Error checking database: {str(e)}",
            "error": str(e)
        }))
    
    finally:
        client.close()

if __name__ == "__main__":
    # Check if we have the right number of arguments
    if len(sys.argv) < 2:
        print(json.dumps({
            "exists": False,
            "message": "Missing required argument: city_name"
        }))
        sys.exit(1)
    
    city_name = sys.argv[1]
    
    try:
        check_database_exists(city_name)
    except Exception as e:
        log(f"Error checking database: {str(e)}")
        print(json.dumps({
            "exists": False,
            "message": f"Error checking database: {str(e)}",
            "error": str(e)
        }))
        sys.exit(1)
