import ScraperControlPanel from "@/components/scraper-control-panel"

export default function Home() {
  return (
    <main>
      <ScraperControlPanel />
    </main>
  )
}
